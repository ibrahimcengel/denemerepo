<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<?php include"header.php" ?>
<br>
<div class="container" >
	
<div class="row" style="height:500px">
	

<div class="col-md-2 " >
	

		<div class="list-group">
  <a href="#" class="list-group-item list-group-item-action active" aria-current="true" style="background-color: #68CA9D; border-color:#68CA9D ;" > 
İşlemler  </a>
  <a href="kulaklik.php" class="list-group-item list-group-item-action">Kulaklıklar</a>

  <a href="kulaklik.php?durum=ekle" class="list-group-item list-group-item-action">Kulaklık Ekle</a>
  
</div>

</div>
<div class="col-md-10 " >
	



<?php



if (empty($_GET['durum'])) {


                     $sayfada = 10; // sayfada gösterilecek içerik miktarını belirtiyoruz.
                     $sorgu=$conn->prepare("select * from kulaklik");
                     $sorgu->execute();
                     $toplam_icerik=$sorgu->rowCount();
                     $toplam_sayfa = ceil($toplam_icerik / $sayfada);
                    // eğer sayfa girilmemişse 1 varsayalım.
                      if(isset($_GET['sayfa'])) {

                      $sayfa =$_GET['sayfa'] ;

                     }else
                     $sayfa=1;



                // eğer 1'den küçük bir sayfa sayısı girildiyse 1 yapalım.
                     if($sayfa < 1) $sayfa = 1; 
                // toplam sayfa sayımızdan fazla yazılırsa en son sayfayı varsayalım.
                     if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
                     $limit = ($sayfa - 1) * $sayfada;



                     //aşağısı bir önceki default kodumuz...
                     

                    


                      $sorgu=$conn->prepare("SELECT * FROM kulaklik ORDER BY tarih DESC  limit $limit,$sayfada");
                      $sorgu->execute();


                  $urunsoryaz=$sorgu->fetchall(PDO::FETCH_ASSOC);


  ?>
  <nav class="navbar bg-light">
  <div class="container-fluid">
    <form class="d-flex" action="#" method="post">
      <input class="form-control me-2" type="search" name="aranan" placeholder="Ad Veya Seri No Giriniz" aria-label="Search">
      <button class="btn btn-outline-success" type="submit" name="ara">Ara</button>
    </form>
  </div>
</nav>
	<table class="table table-striped border">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Seri No</th>
      <th scope="col">Kulaklık Teslim Alan</th>
      <th scope="col">İşlem Yapan Personel</th>
      <th scope="col">Kurum</th>
      <th scope="col">İşlem Tarihi</th>
      <th scope="col">Durum</th>
      <th scope="col" colspan="2">İşlemler</th>
    </tr>
  </thead>
  <?php 
if (isset($_POST['ara'])) {
$isim="%".$_POST['aranan']."%";

$arama = $conn->prepare("SELECT * FROM kulaklik WHERE isim LIKE ? OR seri LIKE ? "); // Arama sorgusu ve limit belirtme
$arama->execute([$isim,$isim]);
$aramayaz=$arama->fetchall(PDO::FETCH_ASSOC);
$toplam=$arama->rowCount();
$say=1;
if ($toplam!=0) {
  // code...




  foreach ($aramayaz as $value) {
    // code...
  ?>
  

     <tr>
      <td ><?php echo $say; ?></td>
  <td ><?php echo $value["seri"] ;?></td>
   <td ><?php echo $value["isim"] ;?></td>
    <td ><?php echo $value["teknik"] ;?></td>
   <td ><?php echo $value["kurum"] ;?></td>
     <td ><?php echo $value["tarih"] ;?></td>
         <td ><?php echo $value["durum"] ;?></td>
       <td ><a href="islem.php?silid=<?php echo $value["id"]; ?>" class="btn btn-danger btn-sm"> Sil</a></td>
         <td ><a href="kulaklik.php?durum=guncelle&id=<?php echo $value["id"] ?>" class="btn btn-primary btn-sm"> Guncelle</a></td>
 
    </tr>




<?php $say++;}?>

</table>



<?php }


else{?>

<tr align="center"><td colspan="8">Kayıt Bulunamadı</td></tr>
</table>

<?php }




}else{

$say=$limit+1;
  foreach ($urunsoryaz as $value) {
  	
  


   ?>
     <tr>
     	<td ><?php echo $say; ?></td>
  <td ><?php echo $value["seri"] ;?></td>
   <td ><?php echo $value["isim"] ;?></td>
    <td ><?php echo $value["teknik"] ;?></td>
   <td ><?php echo $value["kurum"] ;?></td>
     <td ><?php echo $value["tarih"] ;?></td>
         <td ><?php echo $value["durum"] ;?></td>
       <td ><a href="islem.php?silid=<?php echo $value["id"]; ?>" class="btn btn-danger btn-sm"> Sil</a></td>
         <td ><a href="kulaklik.php?durum=guncelle&id=<?php echo $value["id"] ?>" class="btn btn-primary btn-sm"> Guncelle</a></td>
 
    </tr>
 <?php $say++;} ?>



  



</table>
<div style="justify-content: center;" class="row">

    <div class="col-md-4">
                        <ul class="pagination">
 <li>

                              <a href="kulaklik.php?sayfa=1 "><button class=" btn btn-primary btn-sm"><</button></a>

                            </li>
                          <?php

                          $s=0;

                          while ($s < $toplam_sayfa) {

                            $s++; ?>

                            <?php 

                            if ($s==$sayfa) {?>

                            <li class="active">

                              <a href="kulaklik.php?sayfa=<?php echo $s; ?>"><button class=" btn btn-danger btn-sm"><?php echo $s; ?></button></a>

                            </li>

                            <?php } else {?>


                            <li>

                              <a href="kulaklik.php?sayfa=<?php echo $s; ?>"><button class=" btn btn-danger btn-sm"><?php echo $s; ?></button></a>

                            </li>
                            
                            <?php   }


                          }


                          ?>
             <li>

                              <a href="kulaklik.php?sayfa=<?php echo $toplam_sayfa; ?>"><button class=" btn btn-primary btn-sm">></button></a>

                            </li>
                        </ul>
                      </div>
</div>
<?php } ?>
<?php } elseif($_GET['durum']=="ekle") { ?>


		<form  action="islem.php" method="POST">
  <div class="mb-3">
    <label class="form-label"><b>Kulaklık Seri No</b></label>
    <input type="text" class="form-control"  name="seri">
  </div>
   <div class="mb-3">
    <label class="form-label"><b>Teslim Alan Personel Adsoyad</b></label>
    <input type="text" class="form-control"  name="isim">
  </div>
      <div class="mb-3">
     <label class="form-label"><b>İşlem Yapan Teknik Personel </b></label>
  <select class="form-select" aria-label="Default select example" name="teknik">
 <option value="Murat KAMAZOGLU">Murat KAMAZOGLU</option>
<option  value="İbrahim ÇENGEL">İbrahim ÇENGEL</option>
<option value="Ceyhun BUL">Ceyhun BUL</option>
<option value="Kenan COŞAR">Kenan COŞAR</option>
<option  value="Yaşar ÖZTÜRK">Yaşar ÖZTÜRK</option>
<option value="Fatih KÖSE">Fatih KÖSE</option>
<option value="Feyzullah KARABOYA">Feyzullah KARABOYA</option>
<option  value="Burak ÖZKEN">Burak ÖZKEN</option>

</select>
    </div>
   <div class="mb-3">
   	 <label class="form-label"><b>Kurum </b></label>
  <select class="form-select" aria-label="Default select example" name="kurum">
 <option value="Çağrı Alıcı">Çağrı Alıcı</option>
<option  value="Emniyet">Emniyet</option>
<option value="Sağlık">Sağlık</option>
<option value="Jandarma">Jandarma</option>
<option  value="İtfaiye">İtfaiye</option>
<option value="Orman">Orman</option>
<option  value="Afad">Afad</option>

</select>
    </div>
 
  <button type="submit" class="btn btn-primary" name="ekle">Ekle</button>
</form>






<?php 	}elseif ($_GET['durum']=="guncelle") {

 $sorgu=$conn->prepare("select * from kulaklik where id=?");
  $sorgu->execute([$_GET['id']]);
  $kulaklikyaz=$sorgu->fetch(PDO::FETCH_ASSOC);


	?>
		<form  action="islem.php" method="POST">
  <div class="mb-3">
    <label class="form-label"><b>Kulaklık Seri No</b></label>
    <input type="text" class="form-control"  name="seri" value="<?php echo $kulaklikyaz["seri"] ?>">
  </div>
   <div class="mb-3">
    <label class="form-label"><b>Kulaklık Teslim Alan Personel Adsoyad</b></label>
    <input type="text" class="form-control"  name="isim" value="<?php echo $kulaklikyaz["isim"] ?>">
  </div>
  <?php 



   ?>
        <div class="mb-3">
     <label class="form-label"><b>İşlem Yapan Teknik Personel </b></label>
  <select class="form-select" aria-label="Default select example" name="teknik">
 <option value="Murat KAMAZOGLU">Murat KAMAZOGLU</option>
<option  value="İbrahim ÇENGEL" 
<?php if ($kulaklikyaz["teknik"]=="İbrahim ÇENGEL" ){?>

  selected <?php  } ?>

  >İbrahim ÇENGEL</option>
<option value="Ceyhun BUL"
<?php if ($kulaklikyaz["teknik"]=="Ceyhun BUL" ){?>

  selected <?php  } ?>



>Ceyhun BUL</option>
<option value="Kenan COŞAR"
<?php if ($kulaklikyaz["teknik"]=="Kenan COŞAR" ){?>

  selected <?php  } ?>


>Kenan COŞAR</option>
<option  value="Yaşar ÖZTÜRK"
<?php if ($kulaklikyaz["teknik"]=="Yaşar ÖZTÜRK" ){?>

  selected <?php  } ?>




>Yaşar ÖZTÜRK</option>
<option value="Fatih KÖSE"

<?php if ($kulaklikyaz["teknik"]=="Fatih KÖSE" ){?>

  selected <?php  } ?>



>Fatih KÖSE</option>
<option value="Feyzullah KARABOYA"
<?php if ($kulaklikyaz["teknik"]=="Feyzullah KARABOYA" ){?>

  selected <?php  } ?>

>Feyzullah KARABOYA</option>
<option  value="Burak ÖZKEN"

<?php if ($kulaklikyaz["teknik"]=="Burak ÖZKEN" ){?>

  selected <?php  } ?>


>Burak ÖZKEN</option>

</select>
    </div>
   <div class="mb-3">
   	 <label class="form-label"><b>Kurum </b></label>
  <select class="form-select" aria-label="Default select example" name="kurum">
 <option value="Çağrı Alıcı"
<?php if ($kulaklikyaz["kurum"]=="Çağrı Alıcı" ){?>

  selected <?php  } ?>

 >Çağrı Alıcı</option>
<option  value="Emniyet"
<?php if ($kulaklikyaz["kurum"]=="Emniyet" ){?>

  selected <?php  } ?>


>Emniyet</option>
<option value="Sağlık"
<?php if ($kulaklikyaz["kurum"]=="Sağlık" ){?>

  selected <?php  } ?>
>Sağlık</option>
<option value="Jandarma"
<?php if ($kulaklikyaz["kurum"]=="Jandarma" ){?>

  selected <?php  } ?>
>Jandarma</option>
<option  value="İtfaiye"

<?php if ($kulaklikyaz["kurum"]=="İtfaiye" ){?>

  selected <?php  } ?>

>İtfaiye</option>
<option value="Orman"
<?php if ($kulaklikyaz["kurum"]=="Orman" ){?>

  selected <?php  } ?>
>Orman</option>
<option  value="Afad"

<?php if ($kulaklikyaz["kurum"]=="Afad" ){?>

  selected <?php  } ?>

>Afad</option>
</select>
   	 <label class="form-label"><b>Durum </b></label>

  <select class="form-select" aria-label="Default select example" name="durum">
 <option value="Personelde"
<?php if ($kulaklikyaz["durum"]=="Personelde" ){?>

  selected <?php  } ?>

 >Personelde</option>
<option  value="Teslim Alındı Depoda"
<?php if ($kulaklikyaz["durum"]=="Teslim Alındı Depoda" ){?>

  selected <?php  } ?>

>Teslim Alındı Depoda</option>

</select>
    </div>
 <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
  <button type="submit" class="btn btn-primary" name="guncelle">Guncelle</button>
</form>
<?php  } ?>


















</div>
</div>



</div>
<br>
<br>
<br>
<br>
<br>
<br>
<script src="js/bootstrap.min.js" ></script>
</body>
</html>