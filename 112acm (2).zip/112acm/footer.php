
<script src="js/bootstrap.min.js" ></script>


<div class="card bg-light" style="height: 90px; margin-bottom: 0px; background: #DAD714;" >
  <div class="card-body" style="text-align: center; align-content: center;">
  		<b>Copyright ©  Balıkesir Bilgi İşlem Ve Teknik Hizmetler Bürosu <br> Tüm hakları saklıdır.<b>
  </div>
</div>