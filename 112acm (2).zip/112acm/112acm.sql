-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 20 Kas 2022, 14:25:08
-- Sunucu sürümü: 10.4.24-MariaDB
-- PHP Sürümü: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `112acm`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kart`
--

CREATE TABLE `kart` (
  `id` int(11) NOT NULL,
  `seri` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `isim` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `teknik` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `durum` varchar(50) COLLATE utf8_turkish_ci NOT NULL DEFAULT 'Personelde',
  `kurum` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kart`
--

INSERT INTO `kart` (`id`, `seri`, `isim`, `teknik`, `durum`, `kurum`, `tarih`) VALUES
(94, '4444234234234', 'hasan masan', 'İbrahim ÇENGEL', 'Teslim Alındı Depoda', 'Jandarma', '2022-11-19 15:07:30');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kulaklik`
--

CREATE TABLE `kulaklik` (
  `id` int(11) NOT NULL,
  `seri` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `isim` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `teknik` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `durum` varchar(50) COLLATE utf8_turkish_ci NOT NULL DEFAULT 'Personelde',
  `kurum` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kulaklik`
--

INSERT INTO `kulaklik` (`id`, `seri`, `isim`, `teknik`, `durum`, `kurum`, `tarih`) VALUES
(68, '1234567', 'HASAN', 'İbrahim ÇENGEL', 'Teslim Alındı Depoda', 'Emniyet', '2022-11-19 15:30:14');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `liste`
--

CREATE TABLE `liste` (
  `id` int(11) NOT NULL,
  `isim` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `toplamadet` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `yedek` varchar(50) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `liste`
--

INSERT INTO `liste` (`id`, `isim`, `tarih`, `toplamadet`, `yedek`) VALUES
(31, '', '2022-11-20 13:16:44', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sifre`
--

CREATE TABLE `sifre` (
  `id` int(11) NOT NULL,
  `isim` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `pass` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `kadi` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `url` varchar(50) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `sifre`
--

INSERT INTO `sifre` (`id`, `isim`, `pass`, `tarih`, `kadi`, `url`) VALUES
(1, 'Yeni Kameralar', 'admin', '2022-11-18 19:50:22', 'admin', '192.168.2.200'),
(3, 'administrator', 'acil112', '2022-11-18 19:39:30', 'administrator', ''),
(4, 'Sophos', 'kendi şifreniz', '2022-11-18 19:45:58', 'kendi kullanıcı adınız', 'https://10.10.70.11:4444'),
(5, 'Sophos Vpn', 'kendi kullanıcı şifreniz', '2022-11-18 19:45:53', 'kendi kullanıcı adınız', 'https://195.175.104.18:4443'),
(6, 'T.H', 'Teknik2369.', '2022-11-18 19:46:48', 'T.H', 'T.H'),
(7, 'Karel Santral', 'admin', '2022-11-18 19:48:13', 'admin', 'https://192.168.3.240:8088/widea');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `kart`
--
ALTER TABLE `kart`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kulaklik`
--
ALTER TABLE `kulaklik`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `liste`
--
ALTER TABLE `liste`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `sifre`
--
ALTER TABLE `sifre`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `kart`
--
ALTER TABLE `kart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- Tablo için AUTO_INCREMENT değeri `kulaklik`
--
ALTER TABLE `kulaklik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- Tablo için AUTO_INCREMENT değeri `liste`
--
ALTER TABLE `liste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Tablo için AUTO_INCREMENT değeri `sifre`
--
ALTER TABLE `sifre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
