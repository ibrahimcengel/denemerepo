		<?php include "baglan.php"; ?>

    <!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

</head>
<body style="margin-top: 8px; ">

  <div class="container">

    <div>
			<nav class="navbar navbar-expand-lg  " style="background-color: #68CA9D; border-radius:10px;">
  <div class="container-fluid">
    <a  class="navbar-brand " style="margin-left:8px; border-color:#DC0A27 ;" href="index.php"><img src="img/logo.png" width="75px" height="75px"></a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " style="margin-left: 10%;" id="navbarSupportedContent" >
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 " >
          
          <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php"><b>ANASAYFA</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="kulaklik.php"><b>KULAKLIK İŞLEMLERİ</b></a>
        </li>


<li class="nav-item">
          <a class="nav-link active" aria-current="page" href="kart.php"><b>GİRİŞ KARTI İŞLEMLERİ</b></a>
        </li>

<li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sifre.php"><b>ÖNEMLİ ŞİFRELER</b></a>
        </li>

        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="liste.php"><b>ARAÇ GEREÇLER</b></a>
        </li>
        
        
        
      </ul>
    
    </div>

  </div>
</nav>
		</div>