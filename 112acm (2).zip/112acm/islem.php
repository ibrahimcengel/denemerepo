<?php 
include "baglan.php";

 
if (isset($_POST['ekle'])) {
 $sorgu=$conn->prepare("INSERT INTO kulaklik (seri,isim,teknik,kurum) VALUES(?,?,?,?)");
  $sorgu->execute([$_POST["seri"],$_POST["isim"],$_POST["teknik"],$_POST["kurum"]]);
if ($sorgu) {
	header('location:kulaklik.php?');
	exit;
}
}

 
if (isset($_GET['silid'])) {



$sorgu=$conn->prepare("DELETE FROM kulaklik WHERE id = ?");
$sorgu->execute([$_GET['silid']]);


if ($sorgu) {
	header('location:kulaklik.php?');
	exit;
}
}
if (isset($_POST['guncelle'])) {
$sorgu=$conn->prepare("UPDATE  kulaklik SET seri=?,isim=?,teknik=?,kurum=?,durum=? WHERE id=?");
  $sorgu->execute([$_POST["seri"],$_POST["isim"],$_POST["teknik"],$_POST["kurum"],$_POST["durum"],$_POST["id"]]);
if ($sorgu) {
	header('location:kulaklik.php?');
	exit;
}

}

//kartişlemleri

if (isset($_POST['kartekle'])) {
$sorgu=$conn->prepare("INSERT INTO kart (seri,isim,teknik,kurum) VALUES(?,?,?,?)");
  $sorgu->execute([$_POST["seri"],$_POST["isim"],$_POST["teknik"],$_POST["kurum"]]);
if ($sorgu) {
	header('location:kart.php?');
	exit;
}
}

 
if (isset($_GET['kartsilid'])) {



$sorgu=$conn->prepare("DELETE FROM kart WHERE id = ?");
$sorgu->execute([$_GET['kartsilid']]);


if ($sorgu) {
	header('location:kart.php?');
	exit;
}
}
if (isset($_POST['kartguncelle'])) {
$sorgu=$conn->prepare("UPDATE  kart SET seri=?,isim=?,teknik=?,kurum=?,durum=? WHERE id=?");
  $sorgu->execute([$_POST["seri"],$_POST["isim"],$_POST["teknik"],$_POST["kurum"],$_POST["durum"],$_POST["guncelleid"]]);
if ($sorgu) {
	header('location:kart.php?');
	exit;
}

}


//Malzeme İşlemleri
if (isset($_POST['malzemeekle'])) {
$sorgu=$conn->prepare("INSERT INTO liste (isim,toplamadet,yedek) VALUES(?,?,?)");
  $sorgu->execute([$_POST["isim"],$_POST["toplamadet"],$_POST["yedek"]]);
if ($sorgu) {
	header('location:liste.php');
	exit;
}
}

 
if (isset($_GET['malzemesilid'])) {



$sorgu=$conn->prepare("DELETE FROM liste WHERE id = ?");
$sorgu->execute([$_GET['malzemesilid']]);


if ($sorgu) {
	header('location:liste.php');
	exit;
}
}
if (isset($_POST['malzemeguncelle'])) {
$sorgu=$conn->prepare("UPDATE  liste SET isim=?,toplamadet=?,yedek=? WHERE id=?");
  $sorgu->execute([$_POST["isim"],$_POST["toplamadet"],$_POST["yedek"],$_POST["id"]]);
if ($sorgu) {
	header('location:liste.php');
	exit;
}

}



//sifre İşlemleri
if (isset($_POST['sifreekle'])) {
$sorgu=$conn->prepare("INSERT INTO sifre (isim,url,kadi,pass) VALUES(?,?,?,?)");
  $sorgu->execute([$_POST["isim"],$_POST["url"],$_POST["kadi"],$_POST["pass"]]);
if ($sorgu) {
	header('location:sifre.php');
	exit;
}
}

 
if (isset($_GET['sifresilid'])) {



$sorgu=$conn->prepare("DELETE FROM sifre WHERE id = ?");
$sorgu->execute([$_GET['sifresilid']]);


if ($sorgu) {
	header('location:sifre.php');
	exit;
}
}
if (isset($_POST['sifreguncelle'])) {
$sorgu=$conn->prepare("UPDATE  sifre SET isim=?,url=?,kadi=?,pass=?WHERE id=?");
  $sorgu->execute([$_POST["isim"],$_POST["url"],$_POST["kadi"],$_POST["pass"],$_POST["id"]]);
if ($sorgu) {
	header('location:sifre.php');
	exit;
}

}
 ?>