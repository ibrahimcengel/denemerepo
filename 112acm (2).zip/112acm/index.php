

<?php include"header.php"; ?>
<div class="container">
  <br>  

<div class="row">

<div class="col-lg-3 col-md-6 ">

<div class="card" style="width: 18rem;border-color:#68CA9D ;">
  <img src="img/kulaklik.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kulaklık İşlemleri</h5>
    <p class="card-text">Kulaklık Kayıt Etmek Ve Diğer İşlemlerin Bulunduğu Bölüm.</p>
    <a href="kulaklik.php" class="btn btn-primary">Tıklayınız</a>
  </div>
</div>

	</div>

<div class="col-lg-3 col-md-6">

<div class="card" style="width: 18rem; border-color:#68CA9D ;">
  <img src="img/kart2.jpg" style="background-color:white;" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kart İşlemleri</h5>
    <p class="card-text">Kart Kayıt Etmek Ve Diğer İşlemlerin Bulunduğu Bölüm.</p>
    <a href="kart.php" class="btn btn-primary">Tıklayınız</a>
  </div>
</div>

	</div>

<div class="col-lg-3 col-md-6">

<div class="card" style="width: 18rem; border-color: #68CA9D; ">
  <img src="img/sifre3.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Önemli Şifreler</h5>
    <p class="card-text">Teknik Personelin  Bilmesi Gereken Şifrelerin Bulunduğu Bölüm.</p>
    <a href="sifre.php" class="btn btn-primary">Tıklayınız</a>
  </div>
</div>

	</div>
<div class="col-lg-3 col-md-6">

<div class="card" style="width: 18rem; border-color:#68CA9D ;">
  <img src="img/cihazlar.png" style="width: 286px; height: 286px;"class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Cihaz Sayıları</h5>
    <p class="card-text">Bilgi İşlem Bürosu Araç Gereç Sayılarının Bulunduğu Bölüm.</p>
    <a href="liste.php" class="btn btn-primary">Tıklayınız</a>
  </div>
</div>

	</div>

	</div>

<br>
  </div>

<?php include"footer.php"; ?>








</div>
</body>
</html>