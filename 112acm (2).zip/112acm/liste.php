<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
<?php include"header.php" ?>
<br>
<div class="container" >
  
<div class="row" style="height:500px">
  

<div class="col-md-2 " >
  

    <div class="list-group">
  <a href="#" class="list-group-item list-group-item-action active" aria-current="true" style="background-color: #68CA9D; border-color:#68CA9D ;">
İşlemler  </a>
  <a href="liste.php" class="list-group-item list-group-item-action">Malzeme Listesi</a>

  <a href="liste.php?durum=ekle" class="list-group-item list-group-item-action">Malzeme Ekle</a>
  
</div>

</div>
<div class="col-md-10 " >
  



<?php



if (empty($_GET['durum'])) {


                     $sayfada = 10; // sayfada gösterilecek içerik miktarını belirtiyoruz.
                     $sorgu=$conn->prepare("select * from liste");
                     $sorgu->execute();
                     $toplam_icerik=$sorgu->rowCount();
                     $toplam_sayfa = ceil($toplam_icerik / $sayfada);
                    // eğer sayfa girilmemişse 1 varsayalım.
                      if(isset($_GET['sayfa'])) {

                      $sayfa =$_GET['sayfa'] ;

                     }else
                     $sayfa=1;



                // eğer 1'den küçük bir sayfa sayısı girildiyse 1 yapalım.
                     if($sayfa < 1) $sayfa = 1; 
                // toplam sayfa sayımızdan fazla yazılırsa en son sayfayı varsayalım.
                     if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
                     $limit = ($sayfa - 1) * $sayfada;



                     //aşağısı bir önceki default kodumuz...
                     

                    


                      $sorgu=$conn->prepare("SELECT * FROM liste ORDER BY tarih DESC  limit $limit,$sayfada");
                      $sorgu->execute();


                  $urunsoryaz=$sorgu->fetchall(PDO::FETCH_ASSOC);


  ?>
  <nav class="navbar bg-light">
  <div class="container-fluid">
    <form class="d-flex" action="#" method="post">
      <input class="form-control me-2" type="search" name="aranan" placeholder="Malzeme Adı Giriniz" aria-label="Search">
      <button class="btn btn-outline-success" type="submit" name="ara">Ara</button>
    </form>
  </div>
</nav>
  <table class="table table-striped border">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Malzeme Adı</th>
      <th scope="col">Toplam Adet</th>
      <th scope="col">Yedekte Bekleyen</th>
      <th scope="col">İşlem Tarihi</th>
      <th scope="col" colspan="2">İşlemler</th>
    </tr>
  </thead>
  <?php 
if (isset($_POST['ara'])) {
$isim="%".$_POST['aranan']."%";
$arama = $conn->prepare("SELECT * FROM liste WHERE isim LIKE ? "); // Arama sorgusu ve limit belirtme
$arama->execute([$isim]);
$aramayaz=$arama->fetchall(PDO::FETCH_ASSOC);
$toplam=$arama->rowCount();
$say=1;
if ($toplam!=0) {
  // code...




  foreach ($aramayaz as $value) {
    // code...
  ?>
  

     <tr>
      <td ><?php echo $say; ?></td>
  <td ><?php echo $value["isim"] ;?></td>
   <td ><?php echo $value["toplamadet"] ;?></td>
   <td ><?php echo $value["yedek"] ;?></td>
     <td ><?php echo $value["tarih"] ;?></td>
       <td ><a href="islem.php?malzemesilid=<?php echo $value["id"]; ?>" class="btn btn-danger btn-sm"> Sil</a></td>
         <td ><a href="liste.php?durum=malzemeguncelle&id=<?php echo $value["id"] ?>" class="btn btn-primary btn-sm"> Guncelle</a></td>
 
    </tr>




<?php $say++;}?>

</table>



<?php }


else{?>

<tr align="center"><td colspan="7">Kayıt Bulunamadı</td></tr>
</table>

<?php }




}else{

$say=$limit+1;
  foreach ($urunsoryaz as $value) {
    
  


   ?>
     <tr>
      <td ><?php echo $say; ?></td>
  <td ><?php echo $value["isim"] ;?></td>
    <td ><?php echo $value["toplamadet"] ;?></td>
      <td ><?php echo $value["yedek"] ;?></td>
     <td ><?php echo $value["tarih"] ;?></td>
       <td ><a href="islem.php?malzemesilid=<?php echo $value["id"]; ?>" class="btn btn-danger btn-sm"> Sil</a></td>
         <td ><a href="liste.php?durum=malzemeguncelle&id=<?php echo $value["id"] ?>" class="btn btn-primary btn-sm"> Guncelle</a></td>
 
    </tr>
 <?php $say++;} ?>



  



</table>
<div style="justify-content: center;" class="row">

    <div class="col-md-4">
                        <ul class="pagination">
 <li>

                              <a href="liste.php?sayfa=1 "><button class=" btn btn-primary btn-sm"><</button></a>

                            </li>
                          <?php

                          $s=0;

                          while ($s < $toplam_sayfa) {

                            $s++; ?>

                            <?php 

                            if ($s==$sayfa) {?>

                            <li class="active">

                              <a href="liste.php?sayfa=<?php echo $s; ?>"><button class=" btn btn-danger btn-sm"><?php echo $s; ?></button></a>

                            </li>

                            <?php } else {?>


                            <li>

                              <a href="liste.php?sayfa=<?php echo $s; ?>"><button class=" btn btn-danger btn-sm"><?php echo $s; ?></button></a>

                            </li>
                            
                            <?php   }


                          }


                          ?>
             <li>

                              <a href="liste.php?sayfa=<?php echo $toplam_sayfa; ?>"><button class=" btn btn-primary btn-sm">></button></a>

                            </li>
                        </ul>
                      </div>
</div>
<?php } ?>
<?php } elseif($_GET['durum']=="ekle") { ?>


    <form  action="islem.php" method="POST">
  <div class="mb-3">
    <label class="form-label"><b>Malzeme Adı</b></label>
    <input type="text" class="form-control"  name="isim">
  </div>
   <div class="mb-3">
    <label class="form-label"><b>Malzeme Toplam Adeti</b></label>
    <input type="text" class="form-control"  name="toplamadet">
  </div>
    <div class="mb-3">
    <label class="form-label"><b>Malzeme Yedekte Bekleyen</b></label>
    <input type="text" class="form-control"  name="yedek">
  </div>
 
  <button type="submit" class="btn btn-primary" name="malzemeekle">Ekle</button>
</form>






<?php   }elseif ($_GET['durum']=="malzemeguncelle") {

 $sorgu=$conn->prepare("select * from liste where id=?");
  $sorgu->execute([$_GET['id']]);
  $listeyaz=$sorgu->fetch(PDO::FETCH_ASSOC);


  ?>
    <form  action="islem.php" method="POST">
  
   <div class="mb-3">
    <label class="form-label"><b>Malzeme Adı</b></label>
    <input type="text" class="form-control"  name="isim" value="<?php echo $listeyaz["isim"] ?>">
  </div>
  <div class="mb-3">
    <label class="form-label"><b>Malzeme Toplam Adeti</b></label>
    <input type="text" class="form-control"  name="toplamadet" value="<?php echo $listeyaz["toplamadet"] ?>">
  </div>
     <div class="mb-3">
    <label class="form-label"><b>Malzeme Yedekte Bekleyen</b></label>
    <input type="text" class="form-control"  name="yedek" value="<?php echo $listeyaz["yedek"] ?>">
  </div>
  
 <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
  <button type="submit" class="btn btn-primary" name="malzemeguncelle">Guncelle</button>
</form>
<?php  } ?>


















</div>
</div>



</div>
<br>
<br>
<br>
<br>
<br>
<br>
<script src="js/bootstrap.min.js" ></script>

</body>
</html>